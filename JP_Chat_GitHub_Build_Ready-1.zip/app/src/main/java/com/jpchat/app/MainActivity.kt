package com.jpchat.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

private val Navy = Color(0xFF101426)
private val Purple = Color(0xFF8B72FF)
private val Muted = Color(0xFF9CA3B8)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { JPApp() }
    }
}

data class Chat(val name: String, val message: String, val time: String, val initials: String, val unread: Int)

@Composable
fun JPApp() {
    var selectedTab by remember { mutableIntStateOf(0) }
    var selectedChat by remember { mutableStateOf<Chat?>(null) }
    val chats = listOf(
        Chat("Suman", "কাল কথা হবে 😊", "9:42 PM", "S", 2),
        Chat("Riya", "একটা ছবি পাঠিয়েছি", "8:15 PM", "R", 0),
        Chat("Arif", "ঠিক আছে!", "Yesterday", "A", 0),
        Chat("JP Community", "Welcome to JP Chat", "Yesterday", "JP", 5)
    )
    MaterialTheme(colorScheme = darkColorScheme(primary = Purple, background = Navy, surface = Color(0xFF1B2035))) {
        Surface(Modifier.fillMaxSize(), color = Navy) {
            if (selectedChat != null) {
                ChatScreen(chat = selectedChat!!, onBack = { selectedChat = null })
            } else {
                Column(Modifier.fillMaxSize()) {
                    Column(Modifier.padding(horizontal = 20.dp).padding(top = 26.dp, bottom = 18.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Box(
                                Modifier.size(48.dp).background(Brush.linearGradient(listOf(Purple, Color(0xFF4BC7D9))), CircleShape),
                                contentAlignment = Alignment.Center
                            ) { Text("JP", color = Color.White, fontWeight = FontWeight.Black, fontSize = 19.sp) }
                            Spacer(Modifier.width(12.dp))
                            Column(Modifier.weight(1f)) {
                                Text("JP Chat", color = Color.White, fontSize = 25.sp, fontWeight = FontWeight.Bold)
                                Text("Stay connected", color = Muted, fontSize = 12.sp)
                            }
                            IconButton(onClick = {}) { Icon(Icons.Default.Search, "Search", tint = Color.White) }
                            IconButton(onClick = {}) { Icon(Icons.Default.MoreVert, "More", tint = Color.White) }
                        }
                        Spacer(Modifier.height(22.dp))
                        Text("Messages", color = Color.White, fontSize = 23.sp, fontWeight = FontWeight.Bold)
                        Text("তোমার কথোপকথন এখানে", color = Muted, fontSize = 13.sp)
                    }
                    OutlinedTextField(
                        value = "", onValueChange = {}, readOnly = true,
                        placeholder = { Text("Search chats", color = Muted) },
                        leadingIcon = { Icon(Icons.Default.Search, null, tint = Muted) },
                        modifier = Modifier.fillMaxWidth().padding(horizontal = 18.dp),
                        shape = RoundedCornerShape(18.dp),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = Purple, unfocusedBorderColor = Color(0xFF343A53),
                            focusedTextColor = Color.White, unfocusedTextColor = Color.White
                        )
                    )
                    Spacer(Modifier.height(12.dp))
                    LazyColumn(Modifier.weight(1f)) {
                        items(chats) { chat ->
                            Row(
                                Modifier.fillMaxWidth().clickable { selectedChat = chat }.padding(horizontal = 18.dp, vertical = 12.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Box(Modifier.size(54.dp).background(
                                    Brush.linearGradient(listOf(Purple.copy(alpha = .85f), Color(0xFF426D9C))), CircleShape
                                ), contentAlignment = Alignment.Center) {
                                    Text(chat.initials, color = Color.White, fontWeight = FontWeight.Bold, fontSize = 18.sp)
                                }
                                Spacer(Modifier.width(13.dp))
                                Column(Modifier.weight(1f)) {
                                    Text(chat.name, color = Color.White, fontWeight = FontWeight.SemiBold, fontSize = 16.sp)
                                    Spacer(Modifier.height(4.dp))
                                    Text(chat.message, color = Muted, fontSize = 13.sp, maxLines = 1)
                                }
                                Column(horizontalAlignment = Alignment.End) {
                                    Text(chat.time, color = Muted, fontSize = 11.sp)
                                    if (chat.unread > 0) {
                                        Spacer(Modifier.height(7.dp))
                                        Box(Modifier.background(Purple, CircleShape).padding(horizontal = 7.dp, vertical = 3.dp)) {
                                            Text("${chat.unread}", color = Color.White, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                                        }
                                    }
                                }
                            }
                            HorizontalDivider(color = Color(0xFF282D43), modifier = Modifier.padding(start = 85.dp, end = 18.dp))
                        }
                    }
                    NavigationBar(containerColor = Color(0xFF171C30)) {
                        NavigationBarItem(selected = selectedTab == 0, onClick = { selectedTab = 0 },
                            icon = { Icon(Icons.Default.ChatBubble, null) }, label = { Text("Chats") })
                        NavigationBarItem(selected = selectedTab == 1, onClick = { selectedTab = 1 },
                            icon = { Icon(Icons.Default.People, null) }, label = { Text("Contacts") })
                        NavigationBarItem(selected = selectedTab == 2, onClick = { selectedTab = 2 },
                            icon = { Icon(Icons.Default.Settings, null) }, label = { Text("Settings") })
                    }
                }
            }
        }
    }
}

@Composable
fun ChatScreen(chat: Chat, onBack: () -> Unit) {
    var message by remember { mutableStateOf("") }
    val sent = remember { mutableStateListOf<String>() }
    Column(Modifier.fillMaxSize()) {
        Row(Modifier.fillMaxWidth().background(Color(0xFF1B2035)).padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
            IconButton(onClick = onBack) { Icon(Icons.Default.ArrowBack, null, tint = Color.White) }
            Column(Modifier.weight(1f)) {
                Text(chat.name, color = Color.White, fontWeight = FontWeight.Bold)
                Text("Demo conversation", color = Muted, fontSize = 11.sp)
            }
            IconButton(onClick = {}) { Icon(Icons.Default.Call, null, tint = Color.White) }
            IconButton(onClick = {}) { Icon(Icons.Default.Videocam, null, tint = Color.White) }
        }
        Column(Modifier.weight(1f).fillMaxWidth().padding(16.dp), verticalArrangement = Arrangement.Bottom) {
            Box(Modifier.align(Alignment.CenterHorizontally).background(Color(0xFF252B43), RoundedCornerShape(12.dp)).padding(10.dp)) {
                Text("JP Chat demo — messages are not sent online", color = Muted, fontSize = 11.sp)
            }
            Spacer(Modifier.height(16.dp))
            sent.forEach { text ->
                Box(Modifier.align(Alignment.End).padding(vertical = 4.dp).background(Purple, RoundedCornerShape(16.dp)).padding(12.dp)) {
                    Text(text, color = Color.White)
                }
            }
        }
        Row(Modifier.fillMaxWidth().background(Color(0xFF1B2035)).padding(10.dp), verticalAlignment = Alignment.CenterVertically) {
            OutlinedTextField(value = message, onValueChange = { message = it }, modifier = Modifier.weight(1f),
                placeholder = { Text("Write a message…", color = Muted) }, shape = RoundedCornerShape(24.dp),
                colors = OutlinedTextFieldDefaults.colors(focusedBorderColor = Purple, unfocusedBorderColor = Color(0xFF3B4159),
                    focusedTextColor = Color.White, unfocusedTextColor = Color.White))
            IconButton(onClick = { if (message.isNotBlank()) { sent.add(message.trim()); message = "" } }) {
                Icon(Icons.Default.Send, "Send", tint = Purple)
            }
        }
    }
}
